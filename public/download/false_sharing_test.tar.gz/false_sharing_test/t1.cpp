#include <iostream>
#include <thread>

int32_t global[2] = {0};

void foo()
{
    int count = 0;
    for(int i = 0; i < 100000000; i++)
    {
        //++global[0];
        count ++;
    }
    global[0] = count;
}

void bar()
{
    int count = 0;
    for(int i = 0; i < 100000000; i++)
    {
        //++global[1];
        count ++;
    }
    global[1] = count;
}

int main()
{
    std::thread thread1(foo);
    std::thread thread2(bar);
    thread1.join();
    thread2.join();
    return 0;
}

