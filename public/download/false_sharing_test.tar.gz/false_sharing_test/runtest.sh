
echo "====== bench t0 3 times ======"
time ./t0
time ./t0
time ./t0

echo "====== bench t1 3 times ======"
time ./t1
time ./t1
time ./t1

echo "====== bench t2 3 times ======"
time ./t2
time ./t2
time ./t2

echo "====== bench t3 3 times ======"
time ./t3
time ./t3
time ./t3
