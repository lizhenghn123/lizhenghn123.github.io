#include <iostream>
#include <thread>

int32_t global[2] = {0};

void foo()
{
    for(int i = 0; i < 100000000; i++)
    {
        ++global[0];
    }
}

void bar()
{
    for(int i = 0; i < 100000000; i++)
    {
        ++global[1];
    }
}

int main()
{
    std::thread thread1(foo);
    std::thread thread2(bar);
    thread1.join();
    thread2.join();
    return 0;
}

