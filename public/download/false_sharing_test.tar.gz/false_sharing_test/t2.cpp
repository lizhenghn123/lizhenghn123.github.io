#include <iostream>
#include <thread>

__thread int32_t global;

void foo()
{
    for(int i = 0; i < 100000000; i++)
    {
        ++global;
    }
}

void bar()
{
    int count = 0;
    for(int i = 0; i < 100000000; i++)
    {
        ++global;
    }
}

int main()
{
    std::thread thread1(foo);
    std::thread thread2(bar);
    thread1.join();
    thread2.join();
    return 0;
}

