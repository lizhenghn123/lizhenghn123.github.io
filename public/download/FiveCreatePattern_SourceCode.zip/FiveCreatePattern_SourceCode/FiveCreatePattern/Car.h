#pragma once
#include "Vehicle.h"
#include "CarEngine.h"
#include "CarWheel.h"
#include "Singleton.h"

class Car : public Vehicle
{
public:
    Car()
    {
        TRACE_CONSTRUCTION
    }
    virtual ~Car()
    {
        TRACE_CONSTRUCTION
    }
};

class CarAbstructFactory : public VehicleAbstructFactory
{
public:
    CarAbstructFactory()
        : ef_(Singleton<CarEngineFactory>::getInstancePtr())
        , wf_(Singleton<CarWheelFactory>::getInstancePtr())
    {
        TRACE_CONSTRUCTION
    }
    CarAbstructFactory(EngineFactory* ef, WheelFactory* wf)
        : ef_(ef)
        , wf_(wf)
    {
        TRACE_CONSTRUCTION
    }
    virtual ~CarAbstructFactory()
    {
        TRACE_CONSTRUCTION
    }
public:
    virtual Vehicle*  createVehicle()
    {
        return new Car;                  // FIXME �Ƿ�����������Ҳ���Ƿ�����Car����չ���������������Ҳ��Factory
    }
    virtual Engine*   createEngine()
    {
        return ef_->createEngine();
    }
    virtual Wheel*    createWheel()
    {
        return wf_->createWheel();
    }

private:
    EngineFactory* ef_;
    WheelFactory*  wf_;
};

class VehicleAbstructFactory;

class CarBuilder : public VehicleBuilder
{
public:
    CarBuilder::CarBuilder()   // Ĭ��ʹ��CarAbstructFactory����ȻҲ���Դ��ν���
        : vaf_(new CarAbstructFactory)
    {
        TRACE_CONSTRUCTION
        vehicle_ = vaf_->createVehicle();
    }

    explicit CarBuilder::CarBuilder(VehicleAbstructFactory* vaf)
        : vaf_(vaf)
    {
        TRACE_CONSTRUCTION
        vehicle_ = vaf_->createVehicle();
    }

    virtual CarBuilder::~CarBuilder()
    {
        std::cout << "dtor : CarBuilder\n";
    }

    virtual const char* name()
    {
        return "CarBuilder";
    }

protected:
    virtual void buildEngine(Vehicle* v)
    {
        Engine* e1 = vaf_->createEngine();

        v->attach(e1);
    }
    virtual void buildWheel(Vehicle* v)
    {
        Wheel* w = vaf_->createWheel();
        v->attach(w);

        for (int i = 0; i < 3; ++i)    // ����3������
        {
            Wheel* ww = w->clone();
            v->attach(ww);
        }
    }

private:
    VehicleAbstructFactory* vaf_;
};