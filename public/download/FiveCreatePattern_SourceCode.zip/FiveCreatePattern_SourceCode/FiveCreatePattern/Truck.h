#pragma once
#include "Vehicle.h"
#include "TruckEngine.h"
#include "TruckWheel.h"
#include "Singleton.h"

class Truck : public Vehicle
{
public:
    Truck()
    {
        TRACE_CONSTRUCTION
    }
    virtual ~Truck()
    {
        TRACE_CONSTRUCTION
    }
public:
    virtual void run()      // ��������ǰ����Ҫ��һЩ�򵥣�so...
    {
        std::cout << "check something before running of Truck\n";
        Vehicle::run();
    }
};


class TruckAbstructFactory : public VehicleAbstructFactory
{
public:
    TruckAbstructFactory()
        : ef_(Singleton<CarEngineFactory>::getInstancePtr())
        , wf_(Singleton<CarWheelFactory>::getInstancePtr())
    {
        TRACE_CONSTRUCTION
    }
    TruckAbstructFactory(EngineFactory* ef, WheelFactory* wf)
        : ef_(ef)
        , wf_(wf)
    {
        TRACE_CONSTRUCTION
    }
    virtual ~TruckAbstructFactory()
    {
        TRACE_CONSTRUCTION
    }
public:
    virtual Vehicle*  createVehicle()
    {
        return new Truck;                  // FIXME �Ƿ�����������Ҳ���Ƿ�����Truck����չ���������������Ҳ��Factory
    }
    virtual Engine*   createEngine()
    {
        return ef_->createEngine();
    }
    virtual Wheel*    createWheel()
    {
        return wf_->createWheel();
    }

private:
    EngineFactory* ef_;
    WheelFactory*  wf_;
};

class VehicleAbstructFactory;

class TruckBuilder : public VehicleBuilder
{
public:
    TruckBuilder::TruckBuilder()   // Ĭ��ʹ��TruckAbstructFactory����ȻҲ���Դ��ν���
        : vaf_(new TruckAbstructFactory)
    {
        TRACE_CONSTRUCTION
        vehicle_ = vaf_->createVehicle();
    }

    explicit TruckBuilder::TruckBuilder(VehicleAbstructFactory* vaf)
        : vaf_(vaf)
    {
        TRACE_CONSTRUCTION
        vehicle_ = vaf_->createVehicle();
    }

    virtual TruckBuilder::~TruckBuilder()
    {
        std::cout << "dtor : TruckBuilder\n";
    }

    virtual const char* name()
    {
        return "TruckBuilder";
    }

protected:
    virtual void buildEngine(Vehicle* v)
    {
        Engine* e1 = vaf_->createEngine();      // ����˫��������
        Engine* e2 = vaf_->createEngine();

        v->attach(e1);
        v->attach(e2);
    }
    virtual void buildWheel(Vehicle* v)
    {
        Wheel* w = vaf_->createWheel();
        v->attach(w);

        for (int i = 0; i < 7; ++i)    // ����7������
        {
            Wheel* ww = w->clone();
            v->attach(ww);
        }
    }

private:
    VehicleAbstructFactory* vaf_;
};