#pragma once
#include "Engine.h"

class CarEngine : public Engine
{
public:
    CarEngine()
    {
        TRACE_CONSTRUCTION
    }
    virtual ~CarEngine()
    {
        TRACE_CONSTRUCTION
    }

public:
    virtual void fire()
    {
        TRACE_CONSTRUCTION
    }
};


class CarEngineFactory : public EngineFactory, private Singleton<CarEngineFactory>
{
    DECLARE_SINGLETON_CLASS(CarEngineFactory);
public:
    CarEngineFactory()
    {
        TRACE_CONSTRUCTION
    }
    virtual ~CarEngineFactory()
    {
        TRACE_CONSTRUCTION
    }

public:
    virtual Engine*      createEngine()
    {
        return new CarEngine();
    }
};