#include <iostream>
#include "Car.h"
#include "CarEngine.h"
#include "CarWheel.h"
#include "Truck.h"
#include "TruckEngine.h"
#include "TruckWheel.h"
#include "Singleton.h"
using namespace std;

void just_test_constructor()
{
    Car c;
    CarWheel cw;
    CarEngine ce;

    Truck t;
    TruckWheel tw;
    TruckEngine te;

    CarEngineFactory cef;
    CarWheelFactory cwf;

    TruckEngineFactory tef;
    TruckWheelFactory twf;
}

namespace mygoldcar
{
    class CarWheelwithGold : public CarWheel
    {
    public:
        CarWheelwithGold()
        {
            TRACE_CONSTRUCTION
        }
        CarWheelwithGold(const CarWheelwithGold& rhs)
        {
            TRACE_CONSTRUCTION
        }
        virtual ~CarWheelwithGold()
        {
            TRACE_CONSTRUCTION
        }
    public:
        virtual void wheel()            // ���Ľγ�����һ�����ܷ���ֻ�ǿ�����ҫ�¶��ѡ�
        {
            std::cout << "hey, my car's wheels is golden\n";
            CarWheel::wheel();
        }
        virtual Wheel* clone()
        {
            return new CarWheelwithGold(*this);
        }
    };


    class CarWheelwithGoldFactory : public WheelFactory, private Singleton<CarWheelwithGoldFactory>
    {
        DECLARE_SINGLETON_CLASS(CarEngineFactory);
    public:
        CarWheelwithGoldFactory()
        {
            TRACE_CONSTRUCTION
        }
        virtual ~CarWheelwithGoldFactory()
        {
            TRACE_CONSTRUCTION
        }

    public:
        virtual Wheel*      createWheel()
        {
            return new CarWheelwithGold();
        }
    };
}


template<class Builder, class AbstructFactory, class EngineFactory, class WheelFactory>
void test_five_pattern()
{
    VehicleBuilder* builder = new Builder(new AbstructFactory(Singleton<EngineFactory>::getInstancePtr(), Singleton<WheelFactory>::getInstancePtr()));
    builder->builder();

    cout << "### now vehicle[" << builder->name() << "] is ready, so buidler vehicle and run it ###\n";
    Vehicle* v = builder->getVehicle();
    v->run();
}

int main()
{
    //just_test_constructor();
    cout << "\n= = = = = = = = = = = = = = = = = = = = = = =\n";
    test_five_pattern<CarBuilder, CarAbstructFactory, CarEngineFactory, CarWheelFactory>();

    cout << "\n= = = = = = = = = = = = = = = = = = = = = = =\n";
    test_five_pattern<TruckBuilder, TruckAbstructFactory, TruckEngineFactory, TruckWheelFactory>();

    cout << "\n= = = = = = = = = = = = = = = = = = = = = = =\n";
    //  �ðɣ�������һ���߼���ĳ����������䣬���ǳ�������������ʲô��
    test_five_pattern<CarBuilder, CarAbstructFactory, CarEngineFactory, mygoldcar::CarWheelwithGoldFactory>();

    cin.get();
}