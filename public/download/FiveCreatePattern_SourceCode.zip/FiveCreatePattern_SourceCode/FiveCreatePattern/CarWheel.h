#pragma once
#include "Define.h"
#include "Wheel.h"

class CarWheel : public Wheel
{
public:
    CarWheel()
    {
        TRACE_CONSTRUCTION
    }
    CarWheel(const CarWheel& rhs)
    {
        TRACE_CONSTRUCTION
    }
    virtual ~CarWheel()
    {
        TRACE_CONSTRUCTION
    }

public:
    virtual void wheel()
    {
        std::cout << "wheel : CarWheel\n";
    }

    virtual Wheel* clone()
    {
        return new CarWheel(*this);    // ���߲��Ǹ��Ƹ��µģ�����ʹ�ø��ɵģ�
    }
};


class CarWheelFactory : public WheelFactory, private Singleton<CarWheelFactory>
{
    DECLARE_SINGLETON_CLASS(CarWheelFactory);
public:
    CarWheelFactory()
    {
        TRACE_CONSTRUCTION
    }
    virtual ~CarWheelFactory()
    {
        TRACE_CONSTRUCTION
    }

public:
    virtual Wheel*      createWheel()
    {
        return new CarWheel();
    }
};