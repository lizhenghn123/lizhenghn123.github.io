#pragma once
#include <vector>
#include "Engine.h"
#include "Wheel.h"
#include "Define.h"
class Engine;
class Wheel;

class Vehicle
{
public:
    Vehicle::Vehicle()
    {
        TRACE_CONSTRUCTION
    }

    virtual Vehicle::~Vehicle()
    {
        TRACE_CONSTRUCTION
    }

public:
    virtual void run()   // һ����Ϊ����������������ת������,��˸��麯���и�Ĭ��ʵ��
    {
        for (auto e : engines_)
            e->fire();
        for (auto w : wheels_)
            w->wheel();
    }

public:
    void attach(Engine* e)
    {
        engines_.push_back(e);
    }
    void attach(Wheel* w)
    {
        wheels_.push_back(w);
    }

protected:
    std::vector<Engine*>   engines_;     // �ж���������ģ�
    std::vector<Wheel*>    wheels_;      // ���ӿ϶��ж��
};

class VehicleAbstructFactory
{
public:
    VehicleAbstructFactory::VehicleAbstructFactory()
    {
        TRACE_CONSTRUCTION
    }

    virtual VehicleAbstructFactory::~VehicleAbstructFactory()
    {
        TRACE_CONSTRUCTION
    }

public:
    virtual Vehicle*  createVehicle() = 0;
    virtual Engine*   createEngine() = 0;
    virtual Wheel*    createWheel() = 0;
};

class VehicleBuilder
{
public:
    VehicleBuilder::VehicleBuilder()
    {
        TRACE_CONSTRUCTION
    }

    virtual VehicleBuilder::~VehicleBuilder()
    {
        TRACE_CONSTRUCTION
    }

    virtual const char* name() = 0;

protected:
    virtual void buildEngine(Vehicle* v) = 0;
    virtual void buildWheel(Vehicle* v) = 0;

public:
    void  builder()
    {
        buildEngine(vehicle_);
        buildWheel(vehicle_);
    }

    Vehicle* getVehicle() const
    {
        return vehicle_;
    }

protected:
    Vehicle* vehicle_;
};
