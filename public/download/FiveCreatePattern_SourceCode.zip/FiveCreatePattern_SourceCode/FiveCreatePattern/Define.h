#pragma once
#include "Singleton.h"

//#define TRACE_CONSTRUCT_MRCAO

#ifdef TRACE_CONSTRUCT_MRCAO

    #define TRACE_CONSTRUCTION        std::cout << "line:" << __LINE__ << "\t" << __FUNCTION__ << "\n";

#else

    #define TRACE_CONSTRUCTION          (void)1;

#endif
