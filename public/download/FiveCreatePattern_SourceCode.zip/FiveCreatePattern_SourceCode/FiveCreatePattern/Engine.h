#pragma once
#include "Define.h"

class Engine
{
public:
    Engine()
    {
        TRACE_CONSTRUCTION
    }
    virtual ~Engine()
    {
        TRACE_CONSTRUCTION
    }

public:
    virtual void fire() = 0;
};


class EngineFactory
{
public:
    EngineFactory()
    {
        TRACE_CONSTRUCTION
    }
    virtual ~EngineFactory()
    {
        TRACE_CONSTRUCTION
    }

public:
    virtual Engine*      createEngine() = 0;
};