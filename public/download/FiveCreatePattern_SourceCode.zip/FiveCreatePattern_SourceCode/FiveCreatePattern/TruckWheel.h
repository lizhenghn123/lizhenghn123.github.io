#pragma once
#include "Define.h"
#include "Wheel.h"

class TruckWheel : public Wheel
{
public:
    TruckWheel()
    {
        TRACE_CONSTRUCTION
    }
    TruckWheel(const TruckWheel& rhs)
    {
        TRACE_CONSTRUCTION
    }
    virtual ~TruckWheel()
    {
        TRACE_CONSTRUCTION
    }

public:
    virtual void wheel()
    {
        std::cout << "wheel : TruckWheel\n";
    }

    virtual Wheel* clone()
    {
        return new TruckWheel(*this);    // ���߲��Ǹ��Ƹ��µģ�����ʹ�ø��ɵģ�
    }
};


class TruckWheelFactory : public WheelFactory, private Singleton<TruckWheelFactory>
{
    DECLARE_SINGLETON_CLASS(TruckWheelFactory);
public:
    TruckWheelFactory()
    {
        TRACE_CONSTRUCTION
    }
    virtual ~TruckWheelFactory()
    {
        TRACE_CONSTRUCTION
    }

public:
    virtual Wheel*      createWheel()
    {
        return new TruckWheel();
    }
};