#pragma once

class Wheel
{
public:
    Wheel()
    {
        TRACE_CONSTRUCTION
    }
    virtual ~Wheel()
    {
        TRACE_CONSTRUCTION
    }

public:
    virtual void wheel() = 0;
    virtual Wheel* clone() = 0;
};


class WheelFactory
{
public:
    WheelFactory()
    {
        TRACE_CONSTRUCTION
    }
    virtual ~WheelFactory()
    {
        TRACE_CONSTRUCTION
    }

public:
    virtual Wheel*      createWheel() = 0;
};