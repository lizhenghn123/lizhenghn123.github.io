#pragma once
#include "Define.h"
#include "Engine.h"

class TruckEngine : public Engine
{
public:
    TruckEngine()
    {
        TRACE_CONSTRUCTION
    }
    virtual ~TruckEngine()
    {
        TRACE_CONSTRUCTION
    }

public:
    virtual void fire()
    {
        TRACE_CONSTRUCTION
    }
};


class TruckEngineFactory : public EngineFactory, private Singleton<TruckEngineFactory>
{
    DECLARE_SINGLETON_CLASS(TruckEngineFactory);
public:
    TruckEngineFactory()
    {
        TRACE_CONSTRUCTION
    }
    virtual ~TruckEngineFactory()
    {
        TRACE_CONSTRUCTION
    }

public:
    virtual Engine*      createEngine()
    {
        return new TruckEngine();
    }
};